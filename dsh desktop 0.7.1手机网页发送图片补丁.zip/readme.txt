# DSH Desktop 0.7.1 手机端图片发送补丁


DSH Desktop\resources\app\out\main\index.js、

不同安装位置请自行替换路径。



给 DSH Desktop 自带的手机网页端补上图片发送能力。

已验证功能：

- 手机端选择图片
- 图片缩略图预览
- 纯图片发送
- 图片 + 文字发送
- 发送成功后自动清空图片
- 点击缩略图取消当前待发送图片
- 不改 DSH Desktop 原有远程连接、二维码、配对和 Bridge 架构
- 直接复用现有 `session.prompt`

---

# 适用场景

DSH Desktop0.7.1 自带的手机端网页可以正常：

- 连接电脑
- 打开会话
- 发送文字
- 查看回复

但没有：

- 图片按钮
- 手机相册选择
- 多模态图片发送

这个补丁的思路不是重做手机端，也不是换 DSH Mobile / Remote Web UI，而是直接给 DSH Desktop 已经能正常工作的手机网页补上图片输入。

---

# 当前验证环境

本次实际修改的程序目录：

```text
D:\新建文件夹\DSH Desktop